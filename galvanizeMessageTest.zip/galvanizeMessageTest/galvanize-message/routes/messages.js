
'use strict';

const express = require('express');

const router = express.Router();
const knex = require('../knex');
const bodyParser = require('body-parser');

//GET all

router.get('/', (req, res, next)=>{
  knex('messages')
  .select('id', 'name', 'message')
  .then((result)=>{
    res.send(result)
  })
  .catch((err)=>{
    res.status(400).send(err)
  })
})
//GET one by id
router.get('/:id', (req, res, next)=>{
  knex('messages')
  .where('id', req.params.id)
  .select('id', 'name', 'message')
  .then((result)=>{
    res.send(result[0]);
  })
  .catch((err)=>{
    res.status(400).send(err)
  })

})
//POST(insert)
router.post('/', (req, res, next)=>{
  knex('messages')
  //res.set('Content-Type', 'application/json')
  .insert(req.body,['name', 'message'])
  .then((result)=>{
    res.send(result[0]);
  })
  .catch((err)=>{
    res.status(400).send(err)
  });
});

//PATCH
router.patch('/:id', (req, res, next)=>{
  knex('messages')
  .where('id', req.params.id)
  .update(req.body,['id', 'name', 'message'])
  .then((result)=>{
    res.send(result[0]);
  })
  .catch((err)=>{
    res.status(400).send(err)
  })
})

//DELETE
router.delete('/:id', (req, res, next)=>{
  console.log("HEYEYEHEHEHPHEYEYHEYENEHEYYEYEYEYEYEYEYEHHDHSHFSF");
  knex('messages')
.where('id', req.params.id)
// console.log(['id', 'name', 'message']);
.returning(['id', 'name', 'message'])
.del()
.then((result)=>{
  res.send(result[0]);
})
.catch((err)=>{
  res.status(400).send(err)
})

})




module.exports = router;
